package es.ulpgc.aemet;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.IOException;

public class WeatherApiKeyProvider {
    private static final String apiKey = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbmRyZWFtZ29tMj" +
                                     "JAZ21haWwuY29tIiwianRpIjoiNzQ5MjcxYjItZDFhMy00MzA2LWE5YjAtMGE0NTg0ZDJlYzIyIi" +
                                     "wiaXNzIjoiQUVNRVQiLCJpYXQiOjE2NzE2MTI3MjUsInVzZXJJZCI6Ijc0OTI3MWIyLWQxYTMtND" +
                                     "MwNi1hOWIwLTBhNDU4NGQyZWMyMiIsInJvbGUiOiIifQ.h88saz-9SpC2eJ6qRyiEMDEaN9EOEZm" +
                                     "9DW6-WnNQScE";
    public static String response(String url) throws IOException {
        return Jsoup.connect(url)
                .validateTLSCertificates(false)
                .timeout(60000)
                .ignoreContentType(true)
                .header("accept", "application/json")
                .header("api_key", apiKey)
                .method(Connection.Method.GET)
                .maxBodySize(0).execute().body();
    }
}
