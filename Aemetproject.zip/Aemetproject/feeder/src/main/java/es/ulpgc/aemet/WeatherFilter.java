package es.ulpgc.aemet;

import java.util.List;
import java.util.stream.Collectors;

public class WeatherFilter {
    public List<Weather> filterByDate(List<Weather> weatherList, String dateFormat) {
        return weatherList.stream()
                .filter(o -> o.date().replaceAll("T(.*)", "").equals(dateFormat))
                .collect(Collectors.toList());
    }
}

