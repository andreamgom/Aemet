package es.ulpgc.aemet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DatalakeManager {
    private String datalakePath = "datalake";
    private final AemetWeatherDataCollector weatherDataCollector = new AemetWeatherDataCollector();
    private final WeatherFilter writerFilter = new WeatherFilter();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public DatalakeManager() {
        createDatalakeDirectory();
    }

    public void createFile(String date) {
        try {
            File myObj = new File(datalakePath + File.separator + date.replaceAll("-", ""));
            if (myObj.createNewFile()) {
                System.out.println("Archivo creado: " + myObj.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error.");
            e.printStackTrace();
        }
    }

    public void write(String dateFormat) {
        try {
            String content = jsonFormatter(gson.toJson(writerFilter.filterByDate(weatherDataCollector.read(), dateFormat)));
            File file = new File(datalakePath + File.separator + dateFormat.replaceAll("-", ""));
            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(content);
            bufferedWriter.close();
            System.out.println("Archivo escrito");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createDatalakeDirectory() {
        File file = new File(datalakePath);
        if (file.exists()) {
            System.out.println("Carpeta existente");
        } else if (file.mkdir()) {
            System.out.println("Creada");
        } else {
            System.out.println("No creada");
        }
    }
    private String jsonFormatter(String jsonString) {
        return gson.toJson(new JsonParser().parse(jsonString));
    }

    public void create() {
    }
}
