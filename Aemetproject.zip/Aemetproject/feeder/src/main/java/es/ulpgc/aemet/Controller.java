package es.ulpgc.aemet;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Controller {
    private TimerTask task;
    private Timer timer;

    public void Task() {
        task = new TimerTask() {
            public void run(){
                System.out.println("Task performed on: " + new java.util.Date() + "n" );
                new DatalakeManager().create();
                new DatalakeManager().createFile(new DateFormat().todayDateFormat());
                new DatalakeManager().createFile(new DateFormat().yesterdayDateFormat());
                new DatalakeManager().write(new DateFormat().todayDateFormat());
                new DatalakeManager().write(new DateFormat().yesterdayDateFormat());
            }
        };
        timer = new Timer("Timer");
        long delay  = TimeUnit.HOURS.toMillis(1);
        timer.scheduleAtFixedRate(task, delay, delay);
    }
}
