package es.ulpgc.aemet;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class AemetWeatherDataCollector {
    private final static String url = "https://opendata.aemet.es/opendata/api/observacion/convencional/todas";
    private Area area = new Area(27.5, 28.4, -16, -15);

    public List<Weather> read() throws IOException {
        String dataUrl = getDataUrl();
        JsonArray content = getJsonArray(dataUrl);
        return filterAndMapWeatherData(content);
    }

    private String getDataUrl() throws IOException {
        String response = WeatherApiKeyProvider.response(url);
        return JsonParser.parseString(response).getAsJsonObject().get("datos").getAsString();
    }

    private JsonArray getJsonArray(String dataUrl) throws IOException {
        String aemet = WeatherApiKeyProvider.response(dataUrl);
        return new Gson().fromJson(aemet, JsonArray.class);
    }

    private List<Weather> filterAndMapWeatherData(JsonArray content) {
        return content.asList().stream()
                .filter(this::isInArea)
                .map(this::fromJsonToWeather)
                .collect(Collectors.toList());
    }

    private boolean isInArea(JsonElement jsonElement) {
        double lat = jsonElement.getAsJsonObject().get("lat").getAsDouble();
        double lon = jsonElement.getAsJsonObject().get("lon").getAsDouble();
        return lat > area.getFromLat() && lat < area.getToLat() && lon > area.getFromLon() && lon < area.getToLon();
    }

    private Weather fromJsonToWeather(JsonElement jsonElement) {
        try {
            String date = jsonElement.getAsJsonObject().get("date").getAsString();
            String station = jsonElement.getAsJsonObject().get("station").getAsString();
            String location = jsonElement.getAsJsonObject().get("location").getAsString();
            double temperature = jsonElement.getAsJsonObject().get("temperature").getAsDouble();
            double maxTemperature = jsonElement.getAsJsonObject().get("maxTemperature").getAsDouble();
            double minTemperature = jsonElement.getAsJsonObject().get("minTemperature").getAsDouble();
            return new Weather(date, station, location, temperature, maxTemperature, minTemperature);
        } catch (NumberFormatException e) {
            System.out.print("");
        }
        return null;
    }
}
