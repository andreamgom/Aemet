package es.ulpgc.aemet;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateFormat {
    public String todayDateFormat() {
        java.text.DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        return dateFormat.format(calendar.getTime());
    }

    public String yesterdayDateFormat() {
        java.text.DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        return dateFormat.format(calendar.getTime());
    }
}
