package es.ulpgc.aemet;

import java.sql.Connection;
import java.sql.SQLException;

import static java.sql.DriverManager.getConnection;

public class SqliteWrite implements Datamart {
    private final Connection connection;

    public SqliteWrite() throws SQLException {
        connection = getConnection("jdbc:sqlite:database\\datamart.db");
        initDataBase();
    }

    private static final String MAXTEMP =
            "CREATE TABLE IF NOT EXISTS Maxtemp (" +
                    "date PRIMARY KEY , " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER)";
    private static final String MINTEMP =
            "CREATE TABLE IF NOT EXISTS Mintemp (" +
                    "date PRIMARY KEY, " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER)";

    private void initDataBase() throws SQLException {
        connection.createStatement().execute(MAXTEMP);
        connection.createStatement().execute(MINTEMP);
    }

    public void addMax(Weather weather) {
        try {
            connection.createStatement().execute(DMLTranslator.insertTempMaxStatementOf(weather));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addMin(Weather weather) {
        try {
            connection.createStatement().execute(DMLTranslator.insertTempMinStatementOf(weather));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
