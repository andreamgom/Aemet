package es.ulpgc.aemet;

import com.google.gson.JsonObject;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class Datalake {

    public Set<Weather> read(File directory) throws IOException, NullPointerException {
        return Arrays.stream(Objects.requireNonNull(directory.listFiles()))
                .flatMap(file -> {
                    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                        return br.lines().map(line -> {
                            JsonObject jsonObject = new Gson().fromJson(line, JsonObject.class);
                            String instant = jsonObject.getAsJsonPrimitive("timestamp").getAsString();
                            String date = instant.substring(0, 10);
                            String time = instant.substring(11, 19);
                            String stationName = jsonObject.getAsJsonPrimitive("stationName").getAsString();
                            String stationPlace = jsonObject.getAsJsonPrimitive("stationPlace").getAsString();
                            double temp = jsonObject.getAsJsonPrimitive("temperature").getAsDouble();
                            return new Weather(date, stationName, time, stationPlace, temp);
                        });
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }).collect(Collectors.toSet());
    }

    public Weather selectMax(Set<Weather> allEvents) {
        return allEvents.stream().max(Comparator.comparingDouble(Weather::value)).orElse(null);
    }

    public Weather selectMin(Set<Weather> events) {
        return events.stream().min(Comparator.comparingDouble(Weather::value)).orElse(null);
    }

    public void processEvents() throws IOException, SQLException, InterruptedException {
        File directory = new File("datalake");
        Set<Weather> allEvents = read(directory);
        SqliteWrite sqLiteStore = new SqliteWrite();
        Weather maxEvent = selectMax(allEvents);
        Weather minEvent = selectMin(allEvents);
        if (minEvent != null) {
            sqLiteStore.addMin(minEvent);
            System.out.println(minEvent);
        }
        if (maxEvent != null) {
            System.out.println(maxEvent);
            sqLiteStore.addMax(maxEvent);
        }
    }
}