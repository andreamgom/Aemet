package es.ulpgc.aemet;

import java.sql.SQLException;

public interface Datamart {
    void addMin(Weather weather) throws SQLException;

    void addMax(Weather weather) throws SQLException;
}
