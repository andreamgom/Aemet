package es.ulpgc.aemet;

public class DMLTranslator {
    private static final String INSERT_TEMPMAX =
            "INSERT INTO tempMax(date, time, place, station, value) VALUES ('%s', '%s', '%s', '%s', '%f') ON CONFLICT(date) DO NOTHING;";
    private static final String INSERT_TEMPMIN =
            "INSERT INTO tempMin(date, time, place, station, value) VALUES ('%s', '%s', '%s', '%s', '%f') ON CONFLICT(date) DO NOTHING;";

    public static String insertTempMaxStatementOf(Weather weather) {
        return String.format(INSERT_TEMPMAX,
                weather.date(),
                weather.time(),
                weather.place(),
                weather.station(),
                weather.value());
    }

    public static String insertTempMinStatementOf(Weather weather) {
        return String.format(INSERT_TEMPMIN,
                weather.date(),
                weather.time(),
                weather.place(),
                weather.station(),
                weather.value());
    }
}
