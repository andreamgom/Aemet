package es.ulpgc.aemet;

public record Weather(String date, String station, String time, String place, double value) {
    public int compareTo(Weather weather) {
        return 0;
    }
}
