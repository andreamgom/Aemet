package es.ulpgc.aemet;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class SqliteReader implements DatabaseReader{
    public final Connection connection;

    public SqliteReader() throws SQLException {
        String url = "jdbc:sqlite:datamart.db";
        connection = DriverManager.getConnection(url);
    }

    @Override
    public List<Event> read(LocalDate from, LocalDate to, String sql) throws SQLException {
        List<Event> filteredEvents = new ArrayList<>();
        ResultSet resultSet = connection.prepareStatement(sql).executeQuery();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        while (resultSet.next()){
            LocalDate eventDate = LocalDate.parse(resultSet.getString("date"), formatter);

            if(eventDate.isAfter(from) && eventDate.isBefore(to) || eventDate.isEqual(from) || eventDate.isEqual(to)) {
                String time = resultSet.getString("time");
                String station = resultSet.getString("station");
                String place = resultSet.getString("place");
                Double temp = resultSet.getDouble("value");
                filteredEvents.add(new Event(eventDate.toString(), time, station, place, temp));
            }
        }

        return filteredEvents;
    }
}