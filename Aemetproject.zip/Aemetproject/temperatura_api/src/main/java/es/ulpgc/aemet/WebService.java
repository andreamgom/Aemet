package es.ulpgc.aemet;

import spark.Request;
import spark.Response;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static spark.Spark.*;

//http://localhost:4567/
//http://localhost:4567/v1/places/with-max-temerature
public class WebService {
    private final Command eventsManager;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public WebService() throws SQLException {
        this.eventsManager = new EventsWeather();
        port(4567);
        staticFiles.location("/public");
    }

    public void start() {
        get("v1/places/with-max-temerature", this::handleMaxTemperatures);
        get("v1/places/with-min-temerature", this::handleMinTemperatures);
    }

    private String handleMaxTemperatures(Request request, Response response) throws SQLException, NullPointerException {
        response.type("application/json");
        LocalDate from = LocalDate.parse(request.queryParams("from"), formatter);
        LocalDate to = LocalDate.parse(request.queryParams("to"), formatter);
        List<Event> events = eventsManager.getMaxTemperatures(from, to);
        return eventsManager.toJson(events);
    }

    private String handleMinTemperatures(Request request, Response response) throws SQLException {
        response.type("application/json");
        LocalDate from = LocalDate.parse(request.queryParams("from"), formatter);
        LocalDate to = LocalDate.parse(request.queryParams("to"), formatter);
        List<Event> events = eventsManager.getMinTemperatures(from, to);
        return eventsManager.toJson(events);
    }
}
