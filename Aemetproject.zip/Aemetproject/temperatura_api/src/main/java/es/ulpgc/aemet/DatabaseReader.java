package es.ulpgc.aemet;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public interface DatabaseReader {
    List<Event> read(LocalDate from, LocalDate to, String sql) throws SQLException;
}
