package es.ulpgc.aemet;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public interface Command {
    List<Event> getMaxTemperatures(LocalDate from, LocalDate to) throws SQLException;
    List<Event> getMinTemperatures(LocalDate from, LocalDate to) throws SQLException;
    String toJson(List<Event> events);
}
