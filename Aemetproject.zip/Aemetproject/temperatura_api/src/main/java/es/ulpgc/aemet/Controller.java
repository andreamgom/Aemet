package es.ulpgc.aemet;

public class Controller {
    public API api;
    public Controller(API api) {
        this.api = api;
    }
    public void start(){
        api.startServer();
        api.start();
    }
}
