package es.ulpgc.aemet;

public interface API {
    void start();
    void startServer();
}