package es.ulpgc.aemet;

import lombok.Getter;

@Getter
public class Event {
    private final String date;
    private final String time;
    private final String stationName;
    private final String stationPlace;
    private final double temp;

    public Event(String date, String time, String stationName, String stationPlace, double temp) {
        this.date = date;
        this.time = time;
        this.stationName = stationName;
        this.stationPlace = stationPlace;
        this.temp = temp;
    }
}