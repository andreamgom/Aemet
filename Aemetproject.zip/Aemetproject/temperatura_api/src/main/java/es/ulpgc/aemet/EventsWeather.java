package es.ulpgc.aemet;

import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class EventsWeather implements Command{
    public DatabaseReader databaseReader;

    public EventsWeather() throws SQLException {
        this.databaseReader = new SqliteReader();
    }

    private static final String TEMPMAX = "SELECT time, date, place, station, value FROM tempMax";
    private static final String TEMPMIN = "SELECT time, date, place, station, value FROM tempMin";

    @Override
    public List<Event> getMaxTemperatures(LocalDate from, LocalDate to) throws SQLException {
        return databaseReader.read(from, to, TEMPMAX);
    }

    @Override
    public List<Event> getMinTemperatures(LocalDate from, LocalDate to) throws SQLException {
        return databaseReader.read(from, to, TEMPMIN);
    }

    @Override
    public String toJson(List<Event> events) {
        JSONArray jsonArray = new JSONArray();
        for (Event event : events) {
            JSONObject jsonEvent = new JSONObject();
            jsonEvent.put("date", event.getDate());
            jsonEvent.put("time", event.getTime());
            jsonEvent.put("place", event.getStationPlace());
            jsonEvent.put("station", event.getStationName());
            jsonEvent.put("value", event.getTemp());
            jsonArray.put(jsonEvent);
        }
        return jsonArray.toString();
    }
}
